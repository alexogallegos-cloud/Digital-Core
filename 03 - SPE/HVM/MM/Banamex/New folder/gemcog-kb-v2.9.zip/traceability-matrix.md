# Matriz de Trazabilidad — Gemelo Cognitivo Banamex
> Reglas (Capa 2) ↔ Capacidades (Capa 3) ↔ Vocabulario (Capa 1)
> Indexado: ✅ 2026-07-20 — Matriz derivada Capacidad→Reglas (6 niveles) — build-traceability.py
> Generado automáticamente por `build-traceability.py` · 1513 reglas únicas (TRZ-003: -37 duplicados cap-orc/cap-adj · BIAN-002: P021 9.1.1→6.7.2 · TRZ-006: 10.1.1→T.5.1)
> **Tipo-artefacto:** `Matriz-Trazabilidad`  
> **Capa-GemCog:** `Transversal`  
> **Propósito:** Matriz cross-layer Reglas↔Capacidades↔Vocabulario para verificar cobertura completa y detectar reglas, tareas o términos sin vínculo.  
> **Relacionado-con:** task-process-rules-index · vocab-rules-xref · capability-map

## Capacidad BIAN → Reglas

| ID | Capacidad | Reglas | S500 | S151 |
|---|---|---|---|---|
| 7.1.1 | Finance (GL) | 564 | 47 | 517 |
| 6.7.1 | Financial Reconciliation | 106 | 8 | 98 |
| 5.1.1 | Deposits | 93 | 93 | 0 |
| T.4.1 | CFR Regulatory Reporting Pipeline | 85 | 30 | 55 |
| 6.7.2 | Operational Reconciliation | 50 | 45 | 5 |
| 9.1.1 | Operational Data Stores | 75 | 22 | 53 |
| 8.1.1 | Scheduling | 75 | 38 | 37 |
| T.3.4 | Batch Control & Regulatory Extraction | 75 | 5 | 70 |
| 2.1.1 | Teller | 63 | 31 | 32 |
| 6.1.4 | Statements | 60 | 30 | 30 |
| 6.1.5 | Interest & Fees | 57 | 57 | 0 |
| 6.1.3 | Payments | 44 | 24 | 20 |
| 2.2.6 | ATM | 29 | 29 | 0 |
| 6.6.1 | Financial Servicing | 29 | 29 | 0 |
| T.2.3 | MQ / Async (L091 y L093) | 28 | 25 | 3 |
| 4.1.2 | Holdings | 21 | 1 | 20 |
| T.1.3 | Payment Schemes (SPEI/CLABE) | 18 | 18 | 0 |
| 6.5.2 | Compliance & Regulation | 16 | 10 | 6 |
| T.3.5 | Security | 11 | 10 | 1 |
| T.3.1 | Master Data Mgmt. | 8 | 0 | 8 |
| T.5.1 | Batch Orchestration / WFL Orchestrator | 7 | 5 | 2 |

**Total:** 1513 reglas únicas · 22 capacidades · TRZ-003: -37 duplicados (cap-orc/cap-adj) · BIAN-002: P021→6.7.2 · TRZ-006: 10.1.1→T.5.1

