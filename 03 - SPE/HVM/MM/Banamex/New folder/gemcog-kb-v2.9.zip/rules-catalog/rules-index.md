# Catálogo de Reglas — Banamex S151 + S500
> Indexado: ✅ 2026-07-17 — índice Capa 2; los 33 archivos de reglas correlacionados a vocab (Capa 1) y capacidades (Capa 3) vía traceability-matrix.md
> Proyecto: Banamex GemCog · Gemelo Cognitivo Capa 2 (Reglas de Negocio)
> Sistema: Unisys ClearPath MCP · COBOL/ALGOL/DASDL
> Última actualización: 2026-07-17 — Swarm de cobertura total: 82 programas no documentados extraídos (11 archivos nuevos · 704 reglas). Cobertura de programas ahora ~100% (S500 114/114 · S151 104/104)
> **Tipo-artefacto:** `Índice`  
> **Capa-GemCog:** `2`  
> **Propósito:** Índice maestro de los 33 archivos del catálogo de reglas para navegación y recuperación por sistema, programa e intervalo de IDs.  
> **Relacionado-con:** traceability-matrix · vocab-rules-xref · task-process-rules-index

---

## Totales

| Sistema | Archivos | Reglas |
|---------|----------|--------|
| S500 | 12 | 558 |
| S151 | 21 | 992 |
| **Total** | **33** | **1,513** |

> ⚠️ `rules-s151-p112.md` — contiene RN-S151-001..020 como **referencia cruzada** de `rules-s151.md` sección P112 (mismo rango de IDs — verificar si las reglas son equivalentes o complementarias).

---

## S500 — Cargos / Abonos

| Archivo | Programas | Proceso | Reglas | IDs | Estado | Indexado |
|---------|-----------|---------|--------|-----|--------|---------|
| rules-s500.md | P103 · P100 · P075 · P655 · S500P630 · S151/L002R2 · S151/P130 · S151/P015 | BATCH/MIXED/ONLINE | 78 | RN-S500-001..078 | ✅ completo — incluye 23 reglas S151 críticas del portal (⚠️ namespace S500) | ✅ 2026-07-17 |
| rules-s500-p130.md | S500/P130 · WFL LINEA | BATCH/ONLINE | 29 | RN-S500-079..107 | ✅ extraído | ✅ 2026-07-17 |
| rules-s500-p020-p142-p144.md | P020 · P142 · P144 | BATCH | 45 | RN-S500-108..152 | ✅ extraído | ✅ 2026-07-17 |
| rules-s500-s151registra-p103fraude.md | S151REGISTRA · P103 S500 (FraudLink) | MIXED | 30 | RN-S500-153..182 | ✅ extraído | ✅ 2026-07-17 |
| rules-s500-p310.md | P310-CARGA (Captación CPE) | BATCH | 20 | RN-S500-183..202 | ✅ extraído | ✅ 2026-07-17 |
| rules-s500-p010-p110.md | P010 (Teller Gateway) · P280 · P110 (ATM) · P010_PAR · P060 (Access) | ONLINE/BATCH | 44 | RN-S500-203..246 | ✅ extraído (swarm) | ✅ 2026-07-17 |
| rules-s500-deposits-a.md | P170 · P191 · P127 · P109 · P290 · P164 · P115 | BATCH | 42 | RN-S500-261..302 | ✅ extraído (swarm) | ✅ 2026-07-17 |
| rules-s500-deposits-b-interest.md | P107 · P189 · P117 · P168 · P315 · P181 · P187 · P108 · P050 · P199 · P305 · P121 · P330 · P320 | BATCH | 70 | RN-S500-361..430 | ✅ extraído (swarm) | ✅ 2026-07-17 |
| rules-s500-payments-statements.md | P155 · P178 · P176 · P174 · P161 · P179 · P335 · P400 · P185 · P184 · P165 (SPEI) | BATCH/ONLINE | 60 | RN-S500-501..560 | ✅ extraído (swarm) | ✅ 2026-07-17 |
| rules-s500-financial-servicing.md | P105 · P015 · P045 · P180 · P120 · P102 · P005 · P046 · P106 (Compliance) · P160 · P101 | BATCH/ONLINE | 54 | RN-S500-611..664 | ✅ extraído (swarm) | ✅ 2026-07-17 |
| rules-s500-reconciliation.md | P080 · P186 · P104 · P197 · P131 · P195 · P125 · P140 · P190 · P055 · P200 · P188 · P430 · P420 · P091 · P093 (MQ) | BATCH | 56 | RN-S500-721..776 | ✅ extraído (swarm) | ✅ 2026-07-17 |
| rules-s500-algol-wfl-stubs.md | 15 ALGOL · 3 WFL · 5 INC · 7 DASDL | Librería/Schema | 30 | RN-S500-881..910 | ✅ stubs arquitectura (swarm) | ✅ 2026-07-17 |

> **Huecos de reserva S500 (post-swarm):** 247..260 · 303..360 · 431..500 · 561..610 · 665..720 · 777..880 · 911+ — espacios entre bloques de programas, no reglas faltantes.

> Hueco en secuencia S500: RN-S500-056..078 (23 reglas de programas S151 críticos) están en `rules-s500.md`, no en un archivo S151. Considerar migrar a `rules-s151.md` con IDs S151 propios en una iteración futura.

---

## S151 — Movimientos Contables GL

| Archivo | Programas | Reglas | IDs | Estado | Indexado |
|---------|-----------|--------|-----|--------|---------|
| rules-s151-p112.md | P112 — Punteo por claves | 20 | RN-S151-001..020 | ⚠️ referencia cruzada — verificar equivalencia vs rules-s151.md sección P112 | ✅ 2026-07-17 |
| rules-s151.md | P109 — GL Posting Engine | 40 | RN-S151-021..060 | ✅ completo | ✅ 2026-07-17 |
| rules-s151-p130-p131.md | P130 Agrupador · P131 Traductor CFR→CNBV | 42 | RN-S151-061..080 · 091..112 | ✅ migrado + enriquecido | ✅ 2026-07-17 |
| rules-s151-p108-p150.md | P108 GL Bitácora · P150 Reportes CITI | 60 | RN-S151-121..180 | ✅ completo | ✅ 2026-07-17 |
| rules-s151-p021-p120.md | P021 (ALGOL) · P120 Concentrador | 24 | RN-S151-181..185 · 201..207 · 221..232 | ✅ con vocab | ✅ 2026-07-17 |
| rules-s151-p010.md | P010 — Gateway online MOVIMIENTOS | 32 | RN-S151-241..272 | ✅ con vocab | ✅ 2026-07-17 |
| rules-s151-p050-p052.md | P050 CONCENTRACIÓN DE SALDOS · P052 ACCIVAL (Holdings) | 40 | RN-S151-281..300 · 311..330 | ✅ con vocab | ✅ 2026-07-17 |
| rules-s151-p151.md | P151 — Transformador IBM-Citibank ALR/AHR/OCM | 30 | RN-S151-331..360 | ✅ extraído | ✅ 2026-07-17 |
| rules-s151-p158.md | P158 — Movimientos por contrato | 30 | RN-S151-361..390 | ✅ extraído | ✅ 2026-07-17 |
| rules-s151-p178-p138.md | P178 Verificación Saldos · P138 Posición Global | 20 | RN-S151-391..400 · 411..420 | ✅ con vocab | ✅ 2026-07-17 |
| rules-s151-p199-p600.md | P199 · P610 · P612 · P677 | 70 | RN-S151-421..490 | ✅ con vocab | ✅ 2026-07-17 |
| rules-s151-dasdl.md | DASDL BD10 · BD13 · BD99 · BD02 | 35 | RN-S151-491..525 | ✅ con vocab | ✅ 2026-07-17 |
| rules-s151-l030.md | L030 — Librería contable batch | 25 | RN-S151-526..550 | ✅ extraído | ✅ 2026-07-17 |
| rules-s151-p602-p606-p620-p630.md | P602 · P606 · P620 · P630 | 40 | RN-S151-551..590 | ✅ extraído | ✅ 2026-07-17 |
| rules-s151-p655-p670-p671-p680-p690.md | P655 · P670 · P671 · P680 · P690 | 42 | RN-S151-591..632 | ✅ extraído | ✅ 2026-07-17 |
| rules-s151-l002r3-r4-r5.md | L002R3 · L002R4 · L002R5 — ACL GL Interface multi-canal (ALGOL) | 57 | RN-S151-633..659 · 660..674 · 675..689 | ✅ BC-04 completo | ✅ 2026-07-17 |
| rules-s151-p312-p330-p360.md | P312 Saldos S084 · P330 Extracción DMSII · P360 Integración DMSII | 37 | RN-S151-710..718 · 720..732 · 735..749 | ✅ BC-09 completo | ✅ 2026-07-17 |
| rules-s151-contabilidad-a.md | P107 · P167 · P169 · P115 · P135 · P177 · P110 · P117 · P104 · P172 · P116 · P197 · P111 · P128 | 73 | RN-S151-750..822 | ✅ extraído (swarm) | ✅ 2026-07-17 |
| rules-s151-contabilidad-b.md | P122 · P152 · P168 · P114 · P113 · P171 · P153 · P195 · P170 · P196 · P102 · P194 · P103 | 71 | RN-S151-850..920 | ✅ extraído (swarm) | ✅ 2026-07-17 |
| rules-s151-movimientos.md | P053 · P030 · P014 · P055 · L040 · P054 · P005 · P013 · P001 · P025 · P016 · L020 · L014 · P011 · P020 · P071 · P017 · P073 · P090 · P600 | 190 | RN-S151-950..1139 | ✅ extraído (swarm) | ✅ 2026-07-17 |
| rules-s151-algol-wfl-stubs.md | 11 ALGOL (L001 · L006 · L009-L012 · L194 · P000 · P007 · P012 · P810) · 3 WFL (LOTE · LINEA · SPLUNK) | 14 | RN-S151-1150..1163 | ✅ stubs arquitectura (swarm) | ✅ 2026-07-17 |

> **Indexado** = validación vocab+BIAN. Dos niveles según lote:
> - **Archivos originales (21)**: términos COBOL verificados contra `vocab-index-all.txt` + programas contra `bian-mapping`. ✅ = validado.
> - **Archivos del swarm de cobertura total (12, marcados "(swarm)")**: **BIAN 100%** (todos los programas confirmados en `bian-mapping-s500/s151.md`); **vocab reconciliado** — se agregaron 101 términos estructurales faltantes (58 datasets/sistemas S500 + 43 S151, evidencia `reglas-capa2`) al vocab canónico y al índice (ahora 66,570 términos). Trazabilidad de tokens en el campo `Vocabulario en la fórmula`: **50.6% directo / 70.0% ajustado** (ajustado excluye literales numéricos y palabras descriptivas). El 30% ajustado restante son variables de working-storage locales (WS-/W77-/A01-/WKS-) específicas de cada programa, que no son entradas de vocab a nivel campo. Formato inline homologado en los 12 archivos (incl. `rules-s500-p010-p110.md`, convertido de tabla a inline).

> Gaps de numeración S151 (82+8+20=110 IDs sin asignar): 081..090 · 113..120 · 186..200 · 208..220 · 233..240 · 273..280 · 301..310 · 401..410 · 690..709 (reserva BC-04) · 719 · 733..734. Son espacios de reserva entre programas — no hay reglas faltantes.

> **Próximos bloques disponibles:** S151 = 823..849 · 921..949 · 1140..1149 · 1164+ · S500 = ver huecos de reserva arriba. Bloques 750..1163 consumidos por el swarm de cobertura total.

---

## Fuente canónica visual

Las 78 reglas críticas validadas línea por línea en formato interactivo con filtros Dominio · Proceso · Tipo · Regulatorio:

→ GemCog/portal/rules-report-gemcog.html
→ CloudFront: https://dldpl3f6co76b.cloudfront.net/banamex/portal/rules-report-gemcog.html
